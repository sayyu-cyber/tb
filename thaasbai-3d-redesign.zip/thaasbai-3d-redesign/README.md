# Thaasbai — 3D redesign boards

Ten design screens across two directions. Open **`index.html`** to browse them,
or double-click any `.dc.html` file directly. No server, no build step, no
install — they run from the filesystem.

## Direction two — clay, linen and walnut (current)

| File | Screen |
| --- | --- |
| `V2Kit.dc.html` | Materials kit — buttons, surfaces, cards, controls, palette |
| `V2Table3D.dc.html` | **Mindi table, dimensional** — convex playfield, floating cards, deep draw pile |
| `V2Table.dc.html` | Mindi table — earlier flat-plane version |
| `V2Lobby.dc.html` | Home lobby |
| `V2Splash.dc.html` | Splash (phone) |
| `V2Login.dc.html` | Sign in (phone) |

Palette, taken from the moodboard:

```
Warm ivory    #F2EADB   ground, paper, card stock
Warm taupe    #B6A491   linen, quiet surfaces
Terracotta    #B44B2A   the hero action
Olive green   #55552C   the cloth on the table
Walnut brown  #4A2E1C   the table itself, and the ink
```

Ink is `#2B190E`, muted text `#6B5748`, labels `#93816E`.
Type is **Instrument Serif** for display and **Karla** for UI and numerals,
both from Google Fonts.

## Direction one — dark and gold (earlier pass)

`Main.dc.html`, `Table.dc.html`, `Lobby.dc.html`, `Splash.dc.html`,
`Login.dc.html`. Kept for comparison.

## What's interactive

- Every button has a real press — the face drops onto its edge.
- Cards flip on hover; hands fan and lift.
- **The table plays**: click a legal spade, press Play Card, the card lands in
  the trick with a ring on the winner. Off-suit cards are dimmed and
  unclickable, matching the rule the real engine enforces.
- Segmented controls, the sound switch and the password eye all hold state.
- Splash links through to sign in.

## Porting into the app

Everything is plain CSS inside each file's `<style>` block — colours,
material textures, shadows, the press mechanic. Nothing depends on an image
asset, so the textures drop straight into `styles/globals.css` and the
Tailwind theme.

Two things worth fixing in the app at the same time:

1. `lib/motion.ts` is currently a no-op — `riseIn` animates from `opacity: 1`
   to `opacity: 1` and `y: 0` to `y: 0`, and `staggerParent` caps stagger at
   `0.008s`. Every entrance animation in the app does nothing.
2. `styles/globals.css` sets `letter-spacing: 0 !important` on `*`, which
   makes the tracked uppercase labels in these boards impossible.

## About support.js

`support.js` is a small runtime (no dependencies) that renders the boards
outside the design editor they were authored in. Keep it next to the
`.dc.html` files. It is only needed to view them — none of it is meant to
ship in the app.
