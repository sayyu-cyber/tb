/*
 * support.js — a tiny standalone runtime for these design boards.
 *
 * The boards were authored for a canvas editor. This shim implements the
 * small slice of that format they actually use, so every file in this
 * folder opens and stays fully interactive in a plain browser with no
 * build step, no server and no dependencies. Just double-click an .html
 * file (or open index.html first).
 *
 * Supported: <helmet> hoisting, {{dotted.holes}} in text and attributes,
 * <sc-for list as>, <sc-if value>, onClick handlers bound from
 * renderVals(), boolean attributes, and DCLogic state/setState/props.
 */
(function () {
  "use strict";

  function DCLogic(props) {
    this.props = props || {};
    this.state = {};
  }
  DCLogic.prototype.setState = function (patch) {
    var self = this;
    Object.keys(patch || {}).forEach(function (k) {
      self.state[k] = patch[k];
    });
    if (this.__render) this.__render();
  };
  DCLogic.prototype.forceUpdate = function () {
    if (this.__render) this.__render();
  };
  window.DCLogic = DCLogic;

  var HOLE = /\{\{\s*([^}]+?)\s*\}\}/g;
  var WHOLE = /^\{\{\s*([^}]+?)\s*\}\}$/;

  function lookup(path, scope) {
    if (path === "true") return true;
    if (path === "false") return false;
    if (path === "null") return null;
    if (/^-?\d+(\.\d+)?$/.test(path)) return Number(path);
    var parts = path.split(".");
    var val = scope;
    for (var i = 0; i < parts.length; i++) {
      if (val === null || val === undefined) return undefined;
      val = val[parts[i]];
    }
    return val;
  }

  function interpolate(text, scope) {
    return text.replace(HOLE, function (_, path) {
      var v = lookup(path, scope);
      return v === undefined || v === null ? "" : String(v);
    });
  }

  function isBooleanAttr(name) {
    return (
      name === "disabled" ||
      name === "checked" ||
      name === "readonly" ||
      name === "required" ||
      name === "hidden"
    );
  }

  function processElement(el, scope) {
    var attrs = Array.prototype.slice.call(el.attributes);
    attrs.forEach(function (attr) {
      var name = attr.name;
      var value = attr.value;

      if (name.indexOf("hint-") === 0) {
        el.removeAttribute(name);
        return;
      }
      if (value.indexOf("{{") === -1) return;

      // SVG path data is carried as data-d so the browser does not try to
      // parse the unresolved placeholder as geometry and log an error.
      if (name === "data-d") {
        el.removeAttribute(name);
        el.setAttribute("d", interpolate(value, scope));
        return;
      }

      var whole = value.match(WHOLE);
      var raw = whole ? lookup(whole[1], scope) : null;

      if (name.indexOf("on") === 0 && name.length > 2) {
        el.removeAttribute(name);
        if (typeof raw === "function") {
          el.addEventListener(name.slice(2).toLowerCase(), function (event) {
            event.preventDefault();
            raw(event);
          });
        }
        return;
      }

      if (whole && isBooleanAttr(name)) {
        if (raw === true) el.setAttribute(name, "");
        else el.removeAttribute(name);
        return;
      }

      if (whole && (raw === false || raw === null || raw === undefined)) {
        el.removeAttribute(name);
        return;
      }

      el.setAttribute(name, whole ? String(raw) : interpolate(value, scope));
    });
  }

  function processNodes(parent, scope) {
    var nodes = Array.prototype.slice.call(parent.childNodes);

    nodes.forEach(function (node) {
      if (node.nodeType === 3) {
        if (node.nodeValue.indexOf("{{") !== -1) {
          node.nodeValue = interpolate(node.nodeValue, scope);
        }
        return;
      }
      if (node.nodeType !== 1) return;

      var tag = node.tagName.toLowerCase();

      if (tag === "sc-for") {
        var listPath = (node.getAttribute("list") || "").match(WHOLE);
        var list = listPath ? lookup(listPath[1], scope) : [];
        var alias = node.getAttribute("as") || "item";
        var frag = document.createDocumentFragment();

        (list || []).forEach(function (item, index) {
          var inner = document.createDocumentFragment();
          Array.prototype.slice.call(node.childNodes).forEach(function (child) {
            inner.appendChild(child.cloneNode(true));
          });
          var childScope = Object.create(scope);
          childScope[alias] = item;
          childScope.$index = index;
          processNodes(inner, childScope);
          frag.appendChild(inner);
        });

        node.parentNode.replaceChild(frag, node);
        return;
      }

      if (tag === "sc-if") {
        var valPath = (node.getAttribute("value") || "").match(WHOLE);
        var truthy = valPath ? lookup(valPath[1], scope) : false;

        if (truthy) {
          var kept = document.createDocumentFragment();
          Array.prototype.slice.call(node.childNodes).forEach(function (child) {
            kept.appendChild(child);
          });
          processNodes(kept, scope);
          node.parentNode.replaceChild(kept, node);
        } else {
          node.parentNode.removeChild(node);
        }
        return;
      }

      processElement(node, scope);
      processNodes(node, scope);
    });
  }

  function readProps(scriptEl) {
    var props = {};
    var raw = scriptEl && scriptEl.getAttribute("data-props");
    if (!raw) return props;
    try {
      var decoded = raw
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&amp;/g, "&");
      var parsed = JSON.parse(decoded);
      Object.keys(parsed).forEach(function (key) {
        if (key.charAt(0) === "$") return;
        var entry = parsed[key];
        if (entry && typeof entry === "object" && "default" in entry) {
          props[key] = entry.default;
        }
      });
    } catch (err) {
      /* a malformed data-props just means no tweak defaults */
    }
    return props;
  }

  function boot() {
    var host = document.querySelector("x-dc");
    if (!host) return;

    var helmet = host.querySelector("helmet");
    if (helmet) {
      Array.prototype.slice.call(helmet.children).forEach(function (node) {
        document.head.appendChild(node);
      });
      helmet.parentNode.removeChild(helmet);
    }

    var template = document.createElement("div");
    while (host.firstChild) template.appendChild(host.firstChild);

    var scriptEl = document.querySelector("script[data-dc-script]");
    var instance = null;
    if (scriptEl) {
      try {
        var factory = new Function(
          "DCLogic",
          scriptEl.textContent + "\nreturn Component;"
        );
        var Component = factory(DCLogic);
        instance = new Component(readProps(scriptEl));
      } catch (err) {
        console.error("Board logic failed to load:", err);
      }
    }

    var mount = document.createElement("div");
    mount.style.width = "max-content";
    mount.style.margin = "0 auto";
    host.parentNode.replaceChild(mount, host);

    function render() {
      var vals = {};
      if (instance && typeof instance.renderVals === "function") {
        try {
          vals = instance.renderVals() || {};
        } catch (err) {
          console.error("renderVals failed:", err);
        }
      }
      var frag = template.cloneNode(true);
      processNodes(frag, vals);
      mount.innerHTML = "";
      while (frag.firstChild) mount.appendChild(frag.firstChild);
    }

    if (instance) instance.__render = render;
    render();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", boot);
  } else {
    boot();
  }
})();
